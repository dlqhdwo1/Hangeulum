package mail.service;

public interface MailService {

	String mailCheck(String email);

}
