package user.bean;



import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class UserDTO {
	private String userid;
	private String userpassword;
	private String username;
	private String userbirth;
	private String userphone;
	private String gender;
	private String useremail;
	
}
