$(function(){
	alert('hi');
	$('#header-r').hide();
}); 

function cardclick(){
	location.href="loginForm.jsp";
}